import java.util.List;
import java.util.Scanner;


// -- a users class representing a library user --
public class Users {


    // -- attributes of a user --
    private final String userID;
    private final String firstName;
    private final String lastName;
    private final String email;


    // -- this constructor helps to initialize these attributes --
    public Users(String userID, String firstName, String lastName, String email) {
        this.userID = userID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }


    // -- these are getter methods for these user attributes --
    public String getUserID() {
        return userID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }


    // -- method to help convert user ID to user --
    public static Users fromUserIDtoUser(List<Users> users) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please provide the UserID for the loan\n");
        Users userLoan = null;
        while (sc.hasNext()) {
            String inputUserID = sc.next();
            for (Users user : users) {
                if (user.getUserID().equals(inputUserID)) {
                    userLoan = user;
                    break;
                }
            }

            // -- so if the user with the given ID is not found, it will prompt the user to try again --
            if (userLoan == null) {
                System.out.println("The UserID " + inputUserID + " is incorrect or does not exist");
                System.out.println("Please provide the UserID for the loan\n");
                continue;
            }
            break;
        }
        return userLoan;
    }
}


