import java.util.List;
import java.util.Scanner;


// -- this items class represents and provides a generic item in the library --
public abstract class Items {

    private String barcode;
    private String artist;
    private String title;
    private int year;
    private String ISBN;

    // -- constructor to initialize item attributes--
    public Items(String barcode, String artist, String title, int year, String ISBN) {
        this.barcode = barcode;
        this.artist = artist;
        this.title = title;
        this.year = year;
        this.ISBN = ISBN;
    }

    public String getBarcode() {
        return barcode;
    }


    // -- getter methods for item attributes --
    public String getArtist() {
        return artist;
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public String getISBN() {
        return ISBN;
    }

    // -- abstract methods to be implemented by subclasses --

    // -- get the type of the item such as "Book" and "Multimedia"--
    public abstract String getType();


    // -- get the loanable period for the item (in weeks) --
    public abstract int getLoanablePeriod();

    // -- get the maximum renewal period for the item (in weeks) --
    public abstract int getMaxRenewalPeriod();

    // -- get the renewal period for the item (in weeks) --
    public abstract int getRenewalPeriod();


    // -- method to convert barcode to item --
    public static Items fromBarcodeToItem(List<Items> items) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please provide the Barcode of the item:");
        Items itemLoan = null;
        while (scanner.hasNext()) {
            String inputBarcode = scanner.next();

            // -- iterate through the list of items to find the item with the given barcode --
            for (Items item : items) {
                if (item.getBarcode().equals(inputBarcode)) {
                    itemLoan = item;
                    break;
                }
            }
            if (itemLoan == null) {
                System.out.println("The Barcode " + inputBarcode + " is incorrect or does not exist");
                System.out.println("Please provide the Barcode of the item:");
                continue;
            }
            break;
        }
        return itemLoan;
    }


    // -- a toString method to display item information --
    @Override
    public String toString() {
        return "Barcode: " + barcode +
                "; Artist: " + artist +
                "; Title: " + title +
                "; Year: " + year +
                "; ISBN: " + ISBN;
    }
}
