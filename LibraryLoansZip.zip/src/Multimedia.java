import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

// -- multimedia class representing a multimedia item in the library --
public class Multimedia extends Items {


    // -- this constructor helps to initialize these multimedia attributes that we have --
    public Multimedia(String barcode, String artist, String title, int year, String ISBN) {
        super(barcode, artist, title, year, ISBN);
    }


    // -- method to get the type of the item (Multimedia) --
    @Override
    public String getType() {
        return "Multimedia";
    }

    // -- method to get the loanable period for the multimedia item (in weeks) --
    @Override
    public int getLoanablePeriod() {
        return 5;
    }
   // -- method to get the maximum renewal period for the multimedia item (in weeks) --

    @Override
    public int getMaxRenewalPeriod() {
        return 1;
    }

    // -- method to get the renewal period for the multimedia item (in weeks) --
    @Override
    public int getRenewalPeriod() {
        return 3;
    }
}
